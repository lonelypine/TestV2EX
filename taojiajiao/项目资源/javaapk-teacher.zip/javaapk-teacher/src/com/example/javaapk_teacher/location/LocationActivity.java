package com.example.javaapk_teacher.location;

import android.app.Activity;

public class LocationActivity extends Activity {

}
