package com.example.javaapk_teacher.fabu;

import android.support.v4.app.Fragment;

public class Fabu_F_Stranger extends Fragment 
{

}
