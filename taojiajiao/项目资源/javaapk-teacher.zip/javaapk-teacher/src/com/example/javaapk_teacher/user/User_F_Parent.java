package com.example.javaapk_teacher.user;

import android.support.v4.app.Fragment;

public class User_F_Parent extends Fragment {

}
