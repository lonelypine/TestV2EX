package com.example.javaapk_teacher.user;


import com.example.javaapk_teacher.R;
import com.npi.blureffect.Blur;
import com.npi.blureffect.ImageUtils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;

import android.view.ViewGroup;

import android.widget.ImageView;

public class User_F_Stranger extends Fragment {
	
	private ImageView mBlurredImage;

	
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
    {
    	View view=LayoutInflater.from(getActivity()).inflate(R.layout.user_stranger, null);
    	initView(view);
		return view;
    }

	private void initView(View view) 
	{
		final int screenWidth = ImageUtils.getScreenWidth(getActivity());
		mBlurredImage = (ImageView) view.findViewById(R.id.blurred_image);
		
		new Thread(new Runnable() {

			@Override
			public void run() {

				// No image found => let's generate it!
				BitmapFactory.Options options = new BitmapFactory.Options();
				options.inSampleSize = 1;
				Bitmap image = BitmapFactory.decodeResource(getResources(), R.drawable.android_background, options);
				final Bitmap newImg = Blur.fastblur(getActivity(), image, 5);
				getActivity().runOnUiThread(new Runnable() {

					@Override
					public void run() 
					{
						Bitmap image2 = Bitmap.createScaledBitmap(newImg, screenWidth, (int) (newImg.getHeight()* ((float) screenWidth) / (float) newImg.getWidth()), false);
						mBlurredImage.setImageBitmap(image2);
					}
				});

			}
		}).start();
		
		
		
	}
}
