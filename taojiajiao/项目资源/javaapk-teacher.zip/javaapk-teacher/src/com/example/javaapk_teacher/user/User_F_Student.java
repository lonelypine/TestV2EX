package com.example.javaapk_teacher.user;


import com.example.javaapk_teacher.R;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class User_F_Student extends Fragment implements OnClickListener {
	private TextView user_info_tv;
	private TextView user_his_tv;
	private TextView user_experience_tv;
	
	private TextView current_work_tv;
	private TextView current_fabu_tv;
	private TextView parent_word_tv;
	private TextView user_feedback_tv;
	 @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
	    	View view=LayoutInflater.from(getActivity()).inflate(R.layout.user_f, null);
	    	initView(view);
			return view;
	}

	 
	 private void initView(View view)
	 {
			((TextView)view.findViewById(R.id.tv_top_txtTitle)).setText("��������");
			//findView
			user_info_tv = (TextView) view.findViewById(R.id.user_info_tv);
			user_his_tv = (TextView) view.findViewById(R.id.user_his_tv);
			user_experience_tv = (TextView) view.findViewById(R.id.user_experience_tv);
			
			current_fabu_tv = (TextView) view.findViewById(R.id.current_fabu_tv);
			current_work_tv = (TextView) view.findViewById(R.id.current_work_tv);
			parent_word_tv = (TextView) view.findViewById(R.id.parent_word_tv);
			user_feedback_tv = (TextView) view.findViewById(R.id.user_feedback_tv);
			
			//setClick
			user_info_tv.setOnClickListener(this);
			user_his_tv.setOnClickListener(this);
			user_experience_tv.setOnClickListener(this);
			
			current_fabu_tv.setOnClickListener(this);
			current_work_tv.setOnClickListener(this);
			parent_word_tv.setOnClickListener(this);
			user_feedback_tv.setOnClickListener(this);
	 }


	 
	 	
	public void onClick(View arg0) 
	{
	switch (arg0.getId()) 
	{
	case R.id.user_info_tv:
		//�����û���Ϣ����
		break;
	case R.id.user_his_tv:
		//���뽻����ʷ����
		
		break;
	case R.id.user_experience_tv:
		//����ѧϰ�������
		
		break;
	case R.id.current_work_tv:
		//��ǰ���ڼҽ̽���
		
		break;
	case R.id.current_fabu_tv:
		//��ǰ������Ϣ����
		
		break;
	case R.id.parent_word_tv:
		//�ҳ����۽���
		
		break;
	case R.id.user_feedback_tv:
		//�û���������
		
		break;
	default:
		break;
	}	
	}



}
