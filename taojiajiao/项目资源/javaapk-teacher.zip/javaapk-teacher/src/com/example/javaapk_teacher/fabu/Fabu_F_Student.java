package com.example.javaapk_teacher.fabu;

import java.util.Calendar;

import mirko.android.datetimepicker.date.DatePickerDialog;
import mirko.android.datetimepicker.date.DatePickerDialog.OnDateSetListener;

import com.example.javaapk_teacher.R;
import com.mirko.sample.SwipeDismissTouchListener;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class Fabu_F_Student extends Fragment{
	  
	private TextView tvDateBegin;
	private TextView tvDateEnd;
	
	private final Calendar mCalendar = Calendar.getInstance();

	private int day = mCalendar.get(Calendar.DAY_OF_MONTH);

	private int month = mCalendar.get(Calendar.MONTH);

	private int year = mCalendar.get(Calendar.YEAR);

    @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
    {
    	View view=LayoutInflater.from(getActivity()).inflate(R.layout.fabu_f, null);
    	initView(view);
		return view;
    }
    
    private void initView(View view)
    {
    	//ѧ������
    	((TextView)view.findViewById(R.id.tv_top_txtTitle)).setText("����");
    	tvDateBegin = (TextView) view.findViewById(R.id.tvDateBegin);
    	tvDateEnd = (TextView) view.findViewById(R.id.tvDateEnd);
    	
    	tvDateBegin.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// nothing to do, just to let onTouchListener work 

			}
		});
    	//���û�����ʧ
    	tvDateBegin.setOnTouchListener(new SwipeDismissTouchListener(tvDateBegin,
				null,
				new SwipeDismissTouchListener.DismissCallbacks() {
			@Override
			public boolean canDismiss(Object token) {
				return true;
			}

			@Override
			public void onDismiss(View view, Object token) {
				resetDate(tvDateBegin);
			}
		}));
    	
    	tvDateEnd.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// nothing to do, just to let onTouchListener work 

			}
		});
    	
    	tvDateEnd.setOnTouchListener(new SwipeDismissTouchListener(tvDateEnd,
				null,
				new SwipeDismissTouchListener.DismissCallbacks() {
			@Override
			public boolean canDismiss(Object token) {
				return true;
			}

			@Override
			public void onDismiss(View view, Object token) {
				resetDate(tvDateEnd);
			}
		}));
    	
    	
    	//��ʾ��������
    	{
//��ʼ����
    		final DatePickerDialog datePickerDialog = DatePickerDialog.newInstance(new OnDateSetListener() {

    			public void onDateSet(DatePickerDialog datePickerDialog, int year, int month, int day) 
    			{
    				tvDateBegin.setText(
    						new StringBuilder().append(pad(year))
    						.append("-").append(pad(month+1)).append("-").append(pad(day)));
    				tvDateBegin.setTextColor(getResources().getColor(android.R.color.holo_blue_light));
    			}

    		}, mCalendar.get(Calendar.YEAR), mCalendar.get(Calendar.MONTH), mCalendar.get(Calendar.DAY_OF_MONTH));
    		
    		
    		//��������
    		final DatePickerDialog datePickerDialog2 = DatePickerDialog.newInstance(new OnDateSetListener() {

    			public void onDateSet(DatePickerDialog datePickerDialog2, int year, int month, int day) 
    			{
    				tvDateEnd.setText(
    						new StringBuilder().append(pad(year))
    						.append("-").append(pad(month+1)).append("-").append(pad(day)));
    				tvDateEnd.setTextColor(getResources().getColor(android.R.color.holo_blue_light));
    			}

    		}, mCalendar.get(Calendar.YEAR), mCalendar.get(Calendar.MONTH), mCalendar.get(Calendar.DAY_OF_MONTH));

    		
    		
    		view.findViewById(R.id.btnChangeDate1).setOnClickListener(new OnClickListener() {

    			private String tag;

    			@Override
    			public void onClick(View v) {
    				datePickerDialog.show(getFragmentManager(), tag);;
    			}
    		});
    		
    		
    		view.findViewById(R.id.btnChangeDate2).setOnClickListener(new OnClickListener() {

    			private String tag;

    			@Override
    			public void onClick(View v) {
    				datePickerDialog2.show(getFragmentManager(), tag);;
    			}
    		});
    	}
    	
    	
    	
    	
    }
    
    
    
    

    
    
    
    
    
    
	private void resetDate(TextView tv) 
	{
		tv.setText(new StringBuilder().append(pad(year)).append("-").append(pad(month+1)).append("-").append(pad(day)));
		tv.setTextColor(getResources().getColor(android.R.color.darker_gray));
	}

	private static String pad(int c) {
		if (c >= 10)
			return String.valueOf(c);
		else
			return "0" + String.valueOf(c);
	}


}
